<?php
	$classes = [
		'UmiCms\Classes\Components\Emarket\Serializer\Receipt\CloudPayments' => [
			__DIR__ . '/classes/Serializer/Receipt/CloudPayments.php'
		],
	];
