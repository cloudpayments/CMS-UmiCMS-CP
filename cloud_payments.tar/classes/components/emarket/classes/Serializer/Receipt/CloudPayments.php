<?php

	namespace UmiCms\Classes\Components\Emarket\Serializer\Receipt;


	use UmiCms\Classes\Components\Emarket\Serializer\Receipt;


	class CloudPayments extends Receipt {

		/** @const int MAX_ORDER_ITEM_NAME_LENGTH максимальная длина названия товара (0 - первый символ) */
		const MAX_ORDER_ITEM_NAME_LENGTH = 255;

		private $tax = -1;

		/**
		 * Возвращает данные для печати чека
		 * @param \order $order заказ
		 * @return array
		 */
		public function getReceipt(\order $order, $taxSystem, $tax) {
			$this->tax = $tax;
			$data = [
				'cloudPayments' => [
					'customerReceipt' => $this->getOrderItemInfoList($order),
				],
			];
			$data['cloudPayments']['customerReceipt']['taxationSystem'] = (int) $taxSystem;
			$data['cloudPayments']['customerReceipt']['email'] = $this->getContact($order);
			$data['cloudPayments']['customerReceipt']['phone'] = $email = $this->getCustomer($order)->getPhone();
			return $data;
		}

		/** @inheritdoc */
		public function getOrderItemInfoList(\order $order) {
			$orderItemInfoList = [];

			try {
				if (is_array($this->getDeliveryInfo($order))) {
					$orderItemInfoList[] = $this->getDeliveryInfo($order);
				}
			} catch (\expectObjectException $e) {
				//nothing
			}

			foreach ($order->getItems() as $orderItem) {
				if (is_array($this->getOrderItemInfo($order, $orderItem))) {
					$orderItemInfoList[] = $this->getOrderItemInfo($order, $orderItem);
				}
			}

			if (empty($orderItemInfoList)) {
				throw new \publicException(getLabel('error-payment-empty-order'));
			}

			return $this->fixItemPriceSummary($order, $orderItemInfoList);
		}

		protected function getDeliveryInfo(\order $order) {
			$delivery = $this->getDelivery($order);
			if ($order->getDeliveryPrice() == 0) return;
			return [
				'label' => "Доставка: " . $this->prepareItemName($delivery->getName()),
				'quantity' => sprintf('%.2f', 1),
				'price' => sprintf('%.2f', $order->getDeliveryPrice()),
				'amount' => sprintf('%.2f', $order->getDeliveryPrice()),
				'vat' => $this->getCloudPaymentsTaxId($this->getVat($delivery)),
			];
		}

		protected function getOrderItemInfo(\order $order, \orderItem $orderItem) {
			$quantity = $orderItem->getAmount();
			if ($orderItem->getOriginalPrice() == 0) return;
			return [
				'label' => $this->prepareItemName($orderItem->getName()),
				'quantity' => sprintf('%.2f', $quantity),
				'price' => sprintf('%.2f', $orderItem->getOriginalPrice()),
				'amount' => sprintf('%.2f', $this->getAmountPrice($order, $orderItem)),
				'vat' => $this->getCloudPaymentsTaxId($this->getVat($orderItem)),
			];
		}

		private function getAmountPrice(\order $order, \orderItem $orderItem) {
			if (!$order->getDiscountValue()) {
				return $orderItem->getTotalActualPrice();
			}

			$orderItemAmountPrice = $orderItem->getTotalActualPrice() * (100 - $order->getDiscountPercent()) / 100;
			//return round($orderItemAmountPrice, -1, PHP_ROUND_HALF_DOWN);
			return round($orderItemAmountPrice, 0, PHP_ROUND_HALF_DOWN);
		}

				/** @inheritdoc */
		protected function fixItemPriceSummary(\order $order, array $orderItemList) {
			$calculatedOrderPrice = 0;

			foreach ($orderItemList as $orderItemData) {
				$calculatedOrderPrice += $orderItemData['amount'];
			}

			$lastIndex = count($orderItemList) - 1;

			if ($order->getActualPrice() != $calculatedOrderPrice) {
				$priceDiff = $order->getActualPrice() - $calculatedOrderPrice;
				$orderItemList[$lastIndex]['amount'] += $priceDiff;
				$orderItemList[$lastIndex]['amount'] = sprintf('%.2f', $orderItemList[$lastIndex]['amount']);
			}

			return [
				'Items' => $orderItemList
			];
		}


		/** @inheritdoc */
		protected function prepareItemName($name) {
			return mb_substr($name, 0, self::MAX_ORDER_ITEM_NAME_LENGTH);
		}

		/**
		 * Возвращает ставку НДС
		 * @param \orderItem|\delivery $object товарное наименование или доставка
		 * @return iVat
		 * @throws \publicException
		 */
		protected function getVat($object) {
			if ($this->tax == -1) { 
				$rateId = $object->getTaxRateId();
				if (!$rateId) return null;
				return $this->getVatFacade()->get($rateId);
			} 
			return $this->tax;
		}

		private function getCloudPaymentsTaxId($rate)
		{
			if ($rate === null) { 
				return null;	
			}
			if (is_integer($rate) || is_string($rate)) {
				return (int) $rate;
			}

			$name = $rate->getName();
			if (stristr($name, "10/110")) {
				return 110;
			}
			if (stristr($name, "18/118")) {
				return 118;
			}
			if (stristr($name, "10%")) {
				return 10;
			}
			if (stristr($name, "18%")) {
				return 18;
			}
			if (stristr($name, "0%")) {
				return 0;
			}
			return null;
		}

	}
