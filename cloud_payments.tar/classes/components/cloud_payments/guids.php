<?php

// GUID(глобальные идентификаторы) используемые модулем
return [
    'payment_type'		=> 'emarket-payment-cloud_payments',
    'payment_object' 	=> 'emarket-payment-object-cloud_payments',
    'lang_guide' 		=> 'guides-lang-cloud_payments',
    'tax_system_guide' 	=> 'guides-tax_system-cloud_payments',
    'tax_value_guide' 	=> 'guides-tax_value-cloud_payments',
    'auth_status' 		=> 'emarket-orderpaymentstatus-auth-cloud_payments'
];