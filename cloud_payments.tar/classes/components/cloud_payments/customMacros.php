<?php
	/**
	 * Класс пользовательских макросов
	 */
	class Cloud_paymentsCustomMacros {
		/**
		 * @var cloud_payments $module
		 */
		public $module;
	}
?>