<?php
	use UmiCms\Service;
	/**
	 * Класс макросов, то есть методов, доступных в шаблоне
	 */
	class Cloud_paymentsMacros {
		/**
		 * @var cloud_payments $module
		 */

		const EPSILON = 0.1;

		public $module;

		/**
		* Проверка HMAC - для защиты от посороннего обращения и верификации хуков
		*/
		private function checkHMAC() {
			$rawData = file_get_contents("php://input");
			$objectsCollection = umiObjectsCollection::getInstance();
			$cloud = $objectsCollection->getObjectByGUID('emarket-payment-object-cloud_payments');
			if ($cloud) {
				$apiSecret = $cloud->api_secret;
				$s = hash_hmac('sha256', $rawData , $apiSecret, true);
				$encode = base64_encode($s);
				$header = getallheaders()['Content-HMAC'];
				if ($encode != $header) {
					$this->module->printJson(['code' => 13]);
					exit();
				}
			}
			return true;
		}

		/**
		* Обработчик Хука проверки платежа на Фрод
		*/
		public function check() {
			$rawData = file_get_contents("php://input");
			$objectsCollection = umiObjectsCollection::getInstance();
			$this->checkHMAC();
			$invoiceId = $_POST['InvoiceId'];
			$amount = $_POST['Amount'];
			$order = static::getOrderByNumber($invoiceId);
			if ($order && $order->getTypeGUID() == 'emarket-order') {
				if (abs($amount - $order->getValue('total_price')) > self::EPSILON) {
					$this->module->printJson(['code' => 11]);
					exit();
				} 
			} else {
				$this->module->printJson(['code' => 10]);
				exit();
			}

			$this->module->printJson(['code' => 0]);
		}

		/**
		* Обработчика Хука Pay
		*/
		public function pay() {
			$rawData = file_get_contents("php://input");
			$objectsCollection = umiObjectsCollection::getInstance();
			$this->checkHMAC();
			$invoiceId = $_POST['InvoiceId'];
			$status = $_POST['Status'];
			$order = static::getOrderByNumber($invoiceId);
			if ($order && $order->getTypeGUID() == 'emarket-order') {
				if ($status == 'Completed') {
					$this->setPaymentStatus($order, 'accepted');
				} else if ($status == 'Authorized') {
					$this->setPaymentStatus($order, 'authorize');
				}
				
			} else {
				$this->module->printJson(['code' => 10]);
				exit();
			}

			$this->module->printJson(['code' => 0]);
		}

		/**
		* Обработчик Хука подтверждения оплаты при двустадийной модели
		*/
		public function confirm() {
			$rawData = file_get_contents("php://input");
			$objectsCollection = umiObjectsCollection::getInstance();
			$this->checkHMAC();
			$invoiceId = $_POST['InvoiceId'];
			$order = static::getOrderByNumber($invoiceId);
			if ($order && $order->getTypeGUID() == 'emarket-order') {
				$this->setPaymentStatus($order, 'accepted');
			} else {
				$this->module->printJson(['code' => 10]);
				exit();
			}

			$this->module->printJson(['code' => 0]);
		}

		/**
		* Обработчик Хука возвращения средств при двустадийной модели
		*/
		public function refund() {
			$rawData = file_get_contents("php://input");
			$objectsCollection = umiObjectsCollection::getInstance();
			$this->checkHMAC();
			$invoiceId = $_POST['InvoiceId'];
			$order = static::getOrderByNumber($invoiceId);
			if ($order && $order->getTypeGUID() == 'emarket-order') {
				$this->setPaymentStatus($order, 'declined');
			} else {
				$this->module->printJson(['code' => 10]);
				exit();
			}

			$this->module->printJson(['code' => 0]);
		}


		/**
		* Обработчик Хука отмены платежа
		*/
		public function cancel() {
			$rawData = file_get_contents("php://input");
			$objectsCollection = umiObjectsCollection::getInstance();
			$this->checkHMAC();
			$invoiceId = $_POST['InvoiceId'];
			//$order = $objectsCollection->getObject($invoiceId);
			$order = static::getOrderByNumber($invoiceId);
			if ($order && $order->getTypeGUID() == 'emarket-order') {
				$this->setPaymentStatus($order, 'declined');
			} else {
				$this->module->printJson(['code' => 10]);
				exit();
			}

			$this->module->printJson(['code' => 0]);
		}

		private function setPaymentStatus($order, $newStatusId) {
			if ($newStatusId && !is_numeric($newStatusId)) {
				$statusCode = $newStatusId;
				$newStatusId = self::getStatusByCode($newStatusId, 'order_payment_status');
			} else {
				$statusCode = self::getCodeByStatus($newStatusId);
			}


			$order->setValue('payment_status_id', $newStatusId);

			switch ($statusCode) {
				case 'initialized' : {
					$this->setOrderStatus($order, 'payment');
					break;
				}
				case 'declined' : {
					$this->setOrderStatus($order, 'rejected');
					break;
				}
				case 'accepted' : {
					$this->setOrderStatus($order, 'accepted');
					$order->setValue('payment_date', new umiDate());
					break;
				}
			}
		}

		private function setOrderStatus($order, $newStatusId) {
			if ($newStatusId && !is_numeric($newStatusId)) {
				$newStatusId = self::getStatusByCode($newStatusId);

				if (!is_numeric($newStatusId)) {
					return;
				}
			}
			$order->setValue('status_id', $newStatusId);
		}

		private static function getStatusByCode($codename, $statusClass = 'order_status') {
			static $cache = [];

			if (isset($cache[$codename][$statusClass])) {
				return $cache[$codename][$statusClass];
			}

			$sel = new selector('objects');
			$sel->types('object-type')->name('emarket', $statusClass);
			$sel->where('codename')->equals($codename);
			$sel->option('no-length')->value(true);

			return $cache[$codename][$statusClass] = $sel->first() ? $sel->first()->id : false;
		}

		private static function getCodeByStatus($id) {
			static $cache = [];

			if (isset($cache[$id])) {
				return $cache[$id];
			}

			/** @var iUmiObject $status */
			$status = selector::get('object')->id($id);
			return $cache[$id] = $status ? $status->getValue('codename') : false;
		}

		private static function getOrderByNumber($number) {
			$sel = new selector('objects');
			$sel->types('object-type')->guid('emarket-order');
			$sel->where('number')->equals($number);
			$sel->option('no-length')->value(true);
			$sel->limit(0, 1);
			$order = $sel->first();

			if (!$order instanceof iUmiObject) {
				return null;
			}

			return $order;
		}
	}
?>