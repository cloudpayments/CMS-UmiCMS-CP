<?php
	/**
	 * Языковые константы для русской версии
	 */
	$i18n = [
		'module-cloud_payments'			=> 'CloudPayments',
		'header-cloud_payments-welcome'	=> 'Инструкция по настройке',
		'group-account'					=> 'Подключение аккаунта',
        'option-public_id'				=> 'Public ID',
        'option-api_secret'				=> 'API Secret',
        'group-payment_settings'		=> 'Параметры приема платежей',
        'option-widget_language'		=> 'Язык виджета',
        'option-is_two_stage_payment'	=> 'Двухстадийная оплата',
        'group-check_settings'			=> 'Регистрация чеков по 54 ФЗ',
        'option-is_check' 				=> 'Регистрация чеков прихода',
        'option-tax_system' 			=> 'Система налогооблажения',
        'option-tax_value' 				=> 'Налоговая ставка',
		'error-config-not-found' 		=> 'Настройки не найдены',
		'error-page-not-found' 			=> 'Страница не найдена',
		'perms-cloud_payments-guest' 	=> "Права гостя (нужны для корректной работы webhook'ов)",
		'perms-cloud_payments-admin' 	=> "Права администратора",
	];
?>