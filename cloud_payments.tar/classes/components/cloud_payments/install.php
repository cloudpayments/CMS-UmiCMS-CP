<?php

/**
 * @var array $INFO реестр модуля
 */
$INFO = [
    'name'                  => 'cloud_payments', // Имя модуля
    'default_method_admin'  => 'welcome',
];

/**
 * @var array $COMPONENTS файлы модуля
 */
$COMPONENTS = [
    './classes/components/cloud_payments/admin.php',
    './classes/components/cloud_payments/class.php',
    './classes/components/cloud_payments/customAdmin.php',
    './classes/components/cloud_payments/customMacros.php',
    './classes/components/cloud_payments/i18n.php', // языковые константы для Административной часи
    './classes/components/cloud_payments/install.php',
    './classes/components/cloud_payments/lang.php', //языковые константы для Клиентской части
    './classes/components/cloud_payments/macros.php',
    './classes/components/cloud_payments/permissions.php',
    './classes/components/cloud_payments/guids.php',
    './classes/components/cloud_payments/payment_init.php', //для инициализации нового способа оплаты
];

include 'payment_init.php';

?>