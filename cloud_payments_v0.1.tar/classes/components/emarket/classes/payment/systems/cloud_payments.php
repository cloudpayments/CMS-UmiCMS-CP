<?php


use UmiCms\Service;
use UmiCms\Classes\Components\Emarket\Serializer\iReceipt;
use UmiCms\Classes\Components\Emarket\Serializer\Receipt\CloudPayments;

class cloud_paymentsPayment extends payment
{

    public static function getOrderId() {
        return (int) getRequest('order_id');
    }

    public function validate() {
        return true;
    }

    public function process($template = null) {

        $publicId = $this->object->public_id;
        $APIsecret = $this->object->api_secret;

        if(!$publicId || !$APIsecret)
            throw new publicException(getLabel('error-payment-wrong-settings'));

        $objectTypesCollection = umiObjectTypesCollection::getInstance();
        $objectsCollection = umiObjectsCollection::getInstance();

        $this->order->order();

        $currency = $this->getCurrencyCode();
        $amount = $this->formatPrice($this->order->getActualPrice());
  
        $this->order->setPaymentStatus('initialized');
        $orderId = $this->order->getId();
        $numberId = $this->order->getNumber();
        $lang = $objectsCollection->getObject($this->object->widget_language)->getValue('lang_code');
        $taxSystem = $objectsCollection->getObject($this->object->tax_system)->getValue('code');
        $tax = $objectsCollection->getObject($this->object->tax_value)->getValue('value');

        $customer = $objectsCollection->getObject($this->order->getCustomerId());
        $email = $customer->getValue('e-mail') ? $customer->getValue('e-mail') : $customer->getValue('email');

        $isCheck = $this->object->is_check;
        $isTwoStage = $this->object->two_stage_payment;

        $params = [
            'public_id' => $publicId, 
            'widget_language' => $lang,
            'currency' => $currency,
            'amount' => $amount,
            'description' => 'Номер заказа/Order№ ' . $numberId,

            'order_id' => $numberId,
            'customer_id' => $this->order->getCustomerId(),
            'email' => $email,
            'isTwoStage' => $isTwoStage,

            'notify_url' => Service::DomainDetector()->detectUrl() . '/emarket/gateway?order_id=' . $orderId,
        ];
        
        if ($isCheck) {
            $receiptData = $this->getSerializer()->getReceipt($this->order, $taxSystem, $tax);
            $params['receiptData'] = json_encode($receiptData, JSON_UNESCAPED_UNICODE);
        } 
        $this->order->setPaymentStatus('initialized');

        list($templateString) = emarket::loadTemplates(
            'emarket/payment/cloud_payments/' . $template,
            'form_block'
        );

        return emarket::parseTemplate($templateString, $params);
    }

    public function poll() {
        $code = (int) getRequest('code');  
        $redirectUrl = null;   
        if ($code == 200) {
            if (!$this->object->two_stage_payment) {
                $this->order->setPaymentStatus('accepted');
            } else {
                $this->order->setPaymentStatus('authorize');
            }
            $redirectUrl = $this->getSuccessUrl();
        } else {
            $this->order->setPaymentStatus('declined');
            $redirectUrl = $this->getFailUrl();
        }
        Service::Response()->getCurrentBuffer()->redirect($redirectUrl);
    }

    protected function getSerializer() {
        return $this->getSerializerReceiptFactory()->create('CloudPayments');
    }
};
