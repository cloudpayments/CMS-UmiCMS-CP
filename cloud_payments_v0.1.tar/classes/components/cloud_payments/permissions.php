<?php
/**
 * Группы прав на функционал модуля
 */
$permissions = [
    /**
     * Гостевые права
     */
    'guest' => [
        'check',
        'pay',
        'confirm',
        'refund',
        'cancel'
    ],
    /**
     * Административный права
     */
    'admin' => [
        'pages',
    ]
];
?>