<?php
	/**
	 * Языковые константы для русской версии
	 */
	$C_LANG = [
		'module_name' => 'CloudPayments'
	];
?>