<?php

use UmiCms\Service;

// подгрузка массива GUID (глобальных ID)
$GUIDS = include 'guids.php'; 

// Инициализация переменных-коллекций
$objectTypesCollection = umiObjectTypesCollection::getInstance();
$objectsCollection = umiObjectsCollection::getInstance();
$fieldsCollection = umiFieldsCollection::getInstance();
$langsCollection = langsCollection::getInstance();
$domainCollection = domainsCollection::getInstance();

// Добавление нового способа оплаты - CloudPayments
$className = "cloud_payments";
$paymentName = "CloudPayments";
$parentTypeId = $objectTypesCollection->getTypeIdByGUID("emarket-payment");
$internalTypeId = $objectTypesCollection->getTypeIdByGUID("emarket-paymenttype");
$typeId = $objectTypesCollection->addType($parentTypeId, $paymentName);
$internalObjectId = $objectsCollection->addObject($paymentName, $internalTypeId);
$internalObject = $objectsCollection->getObject($internalObjectId);
$internalObject->setValue("class_name", $className); // имя класса для реализации
$internalObject->setValue("payment_type_id", $typeId);
$internalObject->setValue("payment_type_guid", $GUIDS['payment_type']);
$internalObject->commit();
$type = $objectTypesCollection->getType($typeId);
$type->setGUID($internalObject->getValue("payment_type_guid"));
$type->setIsLocked(true);

// Создание справочника для языков виджета, используемых в CloudPayments
$rootGuideTypeId = $objectTypesCollection->getTypeIdByGUID("root-guides-type");
$langDirectoryTypeId = $objectTypesCollection->addType($rootGuideTypeId, "CloudPayments: Языки");
$langDirectoryType = $objectTypesCollection->getType($langDirectoryTypeId);
$langDirectoryType->setIsGuidable(true);
$langDirectoryType->setIsLocked(true);
$langDirectoryType->setGUID($GUIDS['lang_guide']);
$langDirectoryType->addFieldsGroup("lang_settings", "Настройки кодов язков", true, true);
$langDirectoryTypeGroup = $langDirectoryType->getFieldsGroupByName('lang_settings');
$langFieldId = $fieldsCollection->addField('lang_code', 'Language code', 18);
$langField = $fieldsCollection->getField($langFieldId);
$langField->setIsRequired(true);
$langDirectoryTypeGroup->attachField($langFieldId);

// Русский язык
$ruId = $objectsCollection->addObject("Русский", $langDirectoryTypeId);
$ru = $objectsCollection->getObject($ruId);
$ru->setValue("lang_code", "ru-RU");
$ru->commit();
// Английский язык
$en = $objectsCollection->getObject($objectsCollection->addObject("Английский", $langDirectoryTypeId));
$en->setValue("lang_code", "en-US");
$en->commit();
// Латышский язык
$lv = $objectsCollection->getObject($objectsCollection->addObject("Латышский", $langDirectoryTypeId));
$lv->setValue("lang_code", "lv");
$lv->commit();
// Азербайджанский язык
$az = $objectsCollection->getObject($objectsCollection->addObject("Азербайджанский", $langDirectoryTypeId));
$az->setValue("lang_code", "az");
$az->commit();
// Казахский язык
$kk = $objectsCollection->getObject($objectsCollection->addObject("Казахский", $langDirectoryTypeId));
$kk->setValue("lang_code", "kk-KZ");
$kk->commit();
// Украинский язык
$uk = $objectsCollection->getObject($objectsCollection->addObject("Украинский", $langDirectoryTypeId));
$uk->setValue("lang_code", "uk");
$uk->commit();
// Польский язык
$pl = $objectsCollection->getObject($objectsCollection->addObject("Польский", $langDirectoryTypeId));
$pl->setValue("lang_code", "pl");
$pl->commit();
// Португальский язык
$pt = $objectsCollection->getObject($objectsCollection->addObject("Португальский", $langDirectoryTypeId));
$pt->setValue("lang_code", "pt");
$pt->commit();


// Создание справочника для Систем налогооблажений, используемого в CloudPayments
$taxSystemTypeId = $objectTypesCollection->addType($rootGuideTypeId, "CloudPayments: Система налогооблажения");
$taxSystemType = $objectTypesCollection->getType($taxSystemTypeId);
$taxSystemType->setIsGuidable(true);
$taxSystemType->setIsLocked(true);
$taxSystemType->setGUID($GUIDS['tax_system_guide']);
$taxSystemType->addFieldsGroup("tax_system_settings", "Коды для CloudPayments", true, true);
$taxSystemTypeGroup = $taxSystemType->getFieldsGroupByName('tax_system_settings');
$taxSystemTypeFieldId = $fieldsCollection->addField('code', 'CloudPayments code', 18);
$taxSystemTypeField = $fieldsCollection->getField($taxSystemTypeFieldId);
$taxSystemTypeField->setIsRequired(true);
$taxSystemTypeGroup->attachField($taxSystemTypeFieldId);

$_0 = $objectsCollection->getObject($objectsCollection->addObject("Общая система налогообложения", $taxSystemTypeId));
$_0->setValue("code", "0");
$_0->commit();

$_1 = $objectsCollection->getObject($objectsCollection->addObject("Упрощенная система налогообложения (Доход)", $taxSystemTypeId));
$_1->setValue("code", "1");
$_1->commit();

$_2 = $objectsCollection->getObject($objectsCollection->addObject("Упрощенная система налогообложения (Доход минус Расход)", $taxSystemTypeId));
$_2->setValue("code", "2");
$_2->commit();

$_3 = $objectsCollection->getObject($objectsCollection->addObject(" Единый налог на вмененный доход", $taxSystemTypeId));
$_3->setValue("code", "3");
$_3->commit();

$_4 = $objectsCollection->getObject($objectsCollection->addObject("Единый сельскохозяйственный налог", $taxSystemTypeId));
$_4->setValue("code", "4");
$_4->commit();

$_5 = $objectsCollection->getObject($objectsCollection->addObject("Патентная система налогообложения", $taxSystemTypeId));
$_5->setValue("code", "5");
$_5->commit();

// Создание справочника для Налоговых ставок, используемых в CloudPayments
$taxTypeId = $objectTypesCollection->addType($rootGuideTypeId, "CloudPayments: Налоговая ставка");
$taxType = $objectTypesCollection->getType($taxTypeId);
$taxType->setIsGuidable(true);
$taxType->setIsLocked(true);
$taxType->setGUID($GUIDS['tax_value_guide']);
$taxType->addFieldsGroup("tax_value_settings", "Value для CloudPayments", true, true);
$taxTypeGroup = $taxType->getFieldsGroupByName('tax_value_settings');
$taxTypeFieldId = $fieldsCollection->addField('value', 'CloudPayments code', 18);
$taxTypeField = $fieldsCollection->getField($taxTypeFieldId);
$taxTypeGroup->attachField($taxTypeFieldId);

$_18_tax = $objectsCollection->getObject($objectsCollection->addObject("НДС 18%", $taxTypeId));
$_18_tax->setValue("value", 18);
$_18_tax->commit();

$_10_tax = $objectsCollection->getObject($objectsCollection->addObject("НДС 10%", $taxTypeId));
$_10_tax->setValue("value", 10);
$_10_tax->commit();

$without_tax= $objectsCollection->getObject($objectsCollection->addObject("Без НДС", $taxTypeId));
$without_tax->setValue("value", null);
$without_tax->commit();

$_0_tax= $objectsCollection->getObject($objectsCollection->addObject("НДС 0%", $taxTypeId));
$_0_tax->setValue("value", 0);
$_0_tax->commit();

$_118_tax = $objectsCollection->getObject($objectsCollection->addObject("расчетный НДС 18/118", $taxTypeId));
$_118_tax->setValue("value", 118);
$_118_tax->commit();

$_110_tax = $objectsCollection->getObject($objectsCollection->addObject("расчетный НДС 10/110", $taxTypeId));
$_110_tax->setValue("value", 110);
$_110_tax->commit();

$from_umi_tax = $objectsCollection->getObject($objectsCollection->addObject("Брать из UMI.CMS", $taxTypeId));
$from_umi_tax->setValue("value", -1);
$from_umi_tax->commit();

//Создание группы настроек "Подключение аккаунта"
$type->addFieldsGroup("account_settings", "Подключение аккаунта", true, true);
$accountGroup = $type->getFieldsGroupByName('account_settings');

//URL'ы, используемые для обработки хуков (реализацию хуков см. в макросах модуля)
$urlCheck = Service::DomainDetector()->detectUrl() . '/cloud_payments/check';
$urlPay = Service::DomainDetector()->detectUrl() . '/cloud_payments/pay';
$urlConfirm = Service::DomainDetector()->detectUrl() . '/cloud_payments/confirm';
$urlCancel = Service::DomainDetector()->detectUrl() . '/cloud_payments/cancel';
$urlRefund = Service::DomainDetector()->detectUrl() . '/cloud_payments/refund';

$accountGroup->setTip("Если у Вас еще нет аккаунта CloudPayments, то зарегистрируйтесь на нашем <a href='https://cloudpayments.ru/' target='_blank'>сайте</a><br><br>Значения можно найти в личном кабинете CloudPayments (Сайты > Настройки > \"Public ID\" и \"Пароль для API\", <a href='https://raw.githubusercontent.com/cloudpayments/CMS-UmiCMS-CP/master/pics/1.jpg' target='_blank'>посмотреть пример</a>)<br><br>Чтобы модуль защищал платежи от мошенников и отслеживал состояние оплаты заказов, включите в <a href='https://merchant.cloudpayments.ru/' target='_blank'>личном кабинете</a href=''> уведомления (<a href='https://raw.githubusercontent.com/cloudpayments/CMS-UmiCMS-CP/master/pics/2.jpg' target='_blank'>посмотреть пример</a>): <ul><li>\"Check\" - $urlCheck</li><li>\"Pay\" - $urlPay</li><li>\"Confirm\" - $urlConfirm</li><li>\"Refund\" - $urlRefund</li><li>\"Cancel\" - $urlCancel</li></ul> Обязательно проверьте правильность указанных URL, иначе оплаты не будут проходить.");
$public_id_FieldId = $fieldsCollection->addField('public_id', 'Public ID', 18);
$public_id_Field = $fieldsCollection->getField($public_id_FieldId);
$public_id_Field->setIsRequired(true);
$accountGroup->attachField($public_id_FieldId);
$api_secret_FieldId = $fieldsCollection->addField('api_secret', 'API Secret', 18);
$api_secret_Field = $fieldsCollection->getField($api_secret_FieldId);
$api_secret_Field->setIsRequired(true);
$accountGroup->attachField($api_secret_FieldId);

//Создание группы настроек "Параметры приема платежей"
$type->addFieldsGroup("payment_settings", "Параметры приема платежей", true, true);
$paymentGroup = $type->getFieldsGroupByName('payment_settings');
$paymentGroup->setTip("С преимуществами двустадийной оплаты Вы можете ознакомиться <a href='https://cloudpayments.ru/Docs/Integration#schemes' target='_blank'>тут</a>");
$language_FieldId = $fieldsCollection->addField('widget_language', 'Язык виджета', 16);
$language_Field = $fieldsCollection->getField($language_FieldId);
$language_Field->setTip("Если Вы не нашли нужный язык, свяжитесь с нами, и Мы его добавим");
$language_Field->setIsRequired(true);
$language_Field->setGuideId($langDirectoryTypeId);
$paymentGroup->attachField($language_FieldId);
$two_stage_payment_FieldId = $fieldsCollection->addField('two_stage_payment', 'Двустадийная оплата', 1);
$two_stage_payment_Field = $fieldsCollection->getField($two_stage_payment_FieldId);
$two_stage_payment_Field->setIsRequired(false);
$two_stage_payment_Field->setIsVisible(true);
$two_stage_payment_Field->setImportanceStatus(true);
$paymentGroup->attachField($two_stage_payment_FieldId);

//Создание группы настроек "Регистрация чеков по 54 ФЗ"
$type->addFieldsGroup("check_settings", "Регистрация чеков по 54 ФЗ", true, true);
$checkGroup = $type->getFieldsGroupByName('check_settings');
$checkGroup->setTip("Для регистрации чеков <a href='https://cloudkassir.ru/' target='_blank'>подключите</a> Онлайн-кассу CloudCassir");
$tax_system_FieldId = $fieldsCollection->addField('tax_system', 'Система налогооблажения', 16);
$tax_system_Field = $fieldsCollection->getField($tax_system_FieldId);
$tax_system_Field->setIsRequired(true);
$tax_system_Field->setIsVisible(true);
$tax_system_Field->setImportanceStatus(true);
$tax_system_Field->setGuideId($taxSystemTypeId);
$checkGroup->attachField($tax_system_FieldId);
$tax_value_FieldId = $fieldsCollection->addField('tax_value', 'Налоговая ставка', 16);
$tax_value_Field = $fieldsCollection->getField($tax_value_FieldId);
$tax_value_Field->setIsRequired(true);
$tax_value_Field->setIsVisible(true);
$tax_value_Field->setImportanceStatus(true);
$tax_value_Field->setGuideId($taxTypeId);
$checkGroup->attachField($tax_value_FieldId);
$is_check_FieldId = $fieldsCollection->addField('is_check', 'Регистрация чеков прихода', 1);
$is_check_Field = $fieldsCollection->getField($is_check_FieldId);
$is_check_Field->setTip("Доступно только рублевым магазинам. Для каждого платежа автоматически будет регистрироваться чек прихода в соответствии с 54-ФЗ");
$is_check_Field->setIsRequired(false);
$is_check_Field->setIsVisible(true);
$is_check_Field->setImportanceStatus(true);
$checkGroup->attachField($is_check_FieldId);

//Коммитим изменения типа
$type->commit();

// Определение дефолтного языка, используемого на сайте
$domain = $domainCollection->getDefaultDomain();
$langPrefix = $langsCollection->getLang($domain->getDefaultLangId())->getPrefix();
$defLang = $langPrefix == 'en' ? $en : $ru;

//Создаем автоматически объект платежки CloudPayments для автоматизации
// и убыстрения процесса использования
$objId = $objectsCollection->addObject("CloudPayments", $typeId);
$obj = $objectsCollection->getObject($objId);
$obj->setValue("payment_type_id", [$typeId => $type->getName()]);
$obj->setValue("widget_language", $defLang->getName());
$obj->setValue("tax_system", $_3->getName());
$obj->setValue("tax_value", $_18_tax->getName());
$obj->setGUID($GUIDS['payment_object']);
$obj->commit();

//Добавление нового статуса оплаты "Авторизован" для двустадийных платежей
$paymentStatusTypeId = $objectTypesCollection->getTypeIdByGUID('emarket-orderpaymentstatus');
$authStatus = $objectsCollection->getObject($objectsCollection->addObject("Авторизована", $paymentStatusTypeId));
$authStatus->setValue("codename", "authorize");
$authStatus->setGUID($GUIDS['auth_status']);
$authStatus->commit();

//Автоматически назначаем права "guest" модуля CloudPayments для пользователей с правами Гость 
// - для корректной обработки хуков
$permissionsCollection = permissionsCollection::getInstance();
$guestID = $permissionsCollection->getGuestId();
$permissionsCollection->setModulesPermissions($guestID, 'cloud_payments', 'guest', false);

?>