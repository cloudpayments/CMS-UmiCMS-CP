<?php
/**
 * Модуль заглушка
 * 
 */
class cloud_payments extends def_module {

    /**
     * Конструктор
     */
    public function __construct() {
        parent::__construct();

        if (cmsController::getInstance()->getCurrentMode() == "admin") {
            $this->initTabs();
            $this->includeAdminClasses();
        } else {
            $this->includeGuestClasses();
        }

        $this->includeCommonClasses();
    }


    /**
     * Родительский метод удаления + удаление способа оплаты
     */
    public function uninstall() {
        parent::uninstall();
        $guids = include 'guids.php';
        $objectTypesCollection = umiObjectTypesCollection::getInstance();
        $objectsCollection = umiObjectsCollection::getInstance();
        foreach ($guids as $guid) {
            $typeId = $objectTypesCollection->getTypeIdByGUID($guid);
            if ($typeId) { 
                $type = $objectTypesCollection->getType($typeId);
                $type->setIsLocked(false);
                $objectTypesCollection->delType($typeId);
            }
        }
        $authStatusId = $objectsCollection->getObjectIdByGUID($guids['auth_status']);
        if ($authStatusId) {
            $objectsCollection->delObject($authStatusId);
        }
    }

    /**
     * Создает вкладки административной панели модуля
     */
    protected function initTabs() {
        $commonTabs = $this->getCommonTabs();

        if ($commonTabs instanceof iAdminModuleTabs) {
            $commonTabs->add('settings');
        }
    }

    /**
     * Подключает классы функционала административной панели
     */
    protected function includeAdminClasses() {
        $this->__loadLib("admin.php");
        $this->__implement("Cloud_paymentsAdmin");

        $this->loadAdminExtension();

        $this->__loadLib("customAdmin.php");
        $this->__implement("Cloud_paymentsCustomAdmin", true);
    }

    /**
     * Подключает классы функционала клиентской части
     */
    protected function includeGuestClasses() {
        $this->__loadLib("macros.php");
        $this->__implement("Cloud_paymentsMacros");

        $this->loadSiteExtension();

        $this->__loadLib("customMacros.php");
        $this->__implement("Cloud_paymentsCustomMacros", true);
    }

    /**
     * Подключает общие классы функционала
     */
    protected function includeCommonClasses() {
        $this->loadCommonExtension();
        $this->loadTemplateCustoms();
    }
};
?>
