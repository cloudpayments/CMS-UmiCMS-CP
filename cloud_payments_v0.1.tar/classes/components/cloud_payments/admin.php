<?php
/**
 * Класс функционала административной панели
 */
use UmiCms\Service;

class Cloud_paymentsAdmin {

    use baseModuleAdmin;

    /**
     * @var cloud_payments $module
     */
    public $module;

    /**
     * Возвращает приветсвенную страницу модуля
     * @throws coreException
     * @throws expectElementException
     * @throws wrongElementTypeAdminException
     */

    public function welcome() {
        $objectsCollection = umiObjectsCollection::getInstance();
        $GUIDs = include 'guids.php';
        $cloud = $objectsCollection->getObjectByGUID($GUIDs['payment_object']);
        $cloudIdObject = $cloud->getId();

        $url = Service::DomainDetector()->detectUrl() . '/admin/emarket/payment_edit/' . $cloudIdObject;
        $params = ['payment_obj_url' => $url];
        $this->setDataType('list');
        $this->setActionType('view');
 
        $this->setData($params);
        $this->doData();
    }
}
?>