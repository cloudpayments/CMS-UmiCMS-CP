<?php
	/**
	 * Класс пользовательских методов административной панели
	 */
	class Cloud_paymentsCustomAdmin {
		/**
		 * @var  cloud_payments $module
		 */
		public $module;

	}
?>